package com.encore.backend.dto;

import lombok.Data;

@Data
public class LikeInputForm {

    private String userEmail;
}
