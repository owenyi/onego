package com.encore.backend.vo;

import lombok.Data;

@Data
public class TempBoardDeleteInputForm {
    private String boardIdx;
}
