package com.encore.backend.vo;

import lombok.Data;

@Data
public class Memo {
    private int no;
    private String memo;
}
