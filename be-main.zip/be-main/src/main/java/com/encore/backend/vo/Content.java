package com.encore.backend.vo;

import lombok.Data;

@Data
public class Content {
    private int no;
    private String title;
    private String subtitle;
    private String content;
}
