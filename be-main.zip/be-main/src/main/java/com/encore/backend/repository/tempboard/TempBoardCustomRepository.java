package com.encore.backend.repository.tempboard;

import com.encore.backend.vo.TempBoard;

public interface TempBoardCustomRepository {

}
