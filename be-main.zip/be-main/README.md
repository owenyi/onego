# ONEGO BE

## Required(How to run server in VS Code)
#### Install JDK 11 & Set the PATH(JAVA_HOME) Variable
* Link : [Installation of the JDK on Windows](https://docs.oracle.com/en/java/javase/11/install/installation-jdk-microsoft-windows-platforms.html#GUID-A7E27B90-A28D-4237-9383-A58B416071CA)

#### VS Code plugin

```
1. Java Extension Pack
2. Spring Boot Extension Pack
3. Maven for Java
4. Lombok Annotations Support for VS Code
```
